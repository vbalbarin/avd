# Description

The resource is used to wait for a Active Directory Certificate
Services Certificate Authority to become available.
